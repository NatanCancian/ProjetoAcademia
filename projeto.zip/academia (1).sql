-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3308
-- Tempo de geração: 03-Nov-2020 às 03:03
-- Versão do servidor: 8.0.18
-- versão do PHP: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `academia`
--
CREATE DATABASE IF NOT EXISTS `academia` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `academia`;

-- --------------------------------------------------------

--
-- Estrutura da tabela `aluno`
--

CREATE TABLE IF NOT EXISTS `aluno` (
  `id_aluno` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) NOT NULL,
  `data_de_nasc` date NOT NULL,
  `login` varchar(15) NOT NULL,
  `senha` varchar(15) NOT NULL,
  `telefone` varchar(255) NOT NULL,
  `cpf` varchar(15) NOT NULL,
  `rg` varchar(15) NOT NULL,
  `email` varchar(200) NOT NULL,
  `id_plano` int(11) NOT NULL,
  `id_treinamento` int(11) NOT NULL,
  PRIMARY KEY (`id_aluno`),
  KEY `id_plano` (`id_plano`,`id_treinamento`),
  KEY `id_plano_2` (`id_plano`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `aluno`
--

INSERT INTO `aluno` (`id_aluno`, `nome`, `data_de_nasc`, `login`, `senha`, `telefone`, `cpf`, `rg`, `email`, `id_plano`, `id_treinamento`) VALUES
(1, 'Natan Cancian', '2002-09-22', 'natan_cancian', 'natan01', '(45)-998225362', '111.222.343-01', '22.567.980-9', 'natanzaleski@gmail.com', 0, 0),
(43, 'admin', '2020-01-01', 'admin', 'admin', '(45)99822-5362', '222.444.221-00', '33.221.345-0', 'admin@gmail.com', 0, 0),
(45, 'Ademir', '2020-10-24', 'ademir', 'ademir', '(22)92389-0987', '112.332.123-01', '21.324.567-1', 'ademir@gmail.com', 0, 0),
(46, 'Vinicius Zaleski', '0902-02-02', 'viniciusZ', 'zaleskao', '(11)99802-9876', '112.221.223-00', '12.332.123.-1', 'vinicius@gmail.com', 0, 0),
(48, 'Zeca Urubu', '1980-01-01', 'zeca_urubu', 'zeca', '(21)99213-2122', '221.222.678-09', '12.333.442-0', 'zecaurubu@gmail.com', 0, 0),
(49, 'Juca bala', '1911-01-01', 'juca bala', 'jucao', '(11)99990-0099', '111.222.333-00', '11.222.333-0', 'jucabala@hotmail.com', 0, 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `avaliacao_fisica`
--

CREATE TABLE IF NOT EXISTS `avaliacao_fisica` (
  `id_avaliacao` int(11) NOT NULL AUTO_INCREMENT,
  `data_e_hora` datetime NOT NULL,
  `preco` varchar(10) NOT NULL,
  `id_aluno` int(11) NOT NULL,
  `id_funcionario` int(11) NOT NULL,
  PRIMARY KEY (`id_avaliacao`),
  KEY `id_aluno` (`id_aluno`),
  KEY `id_funcionario` (`id_funcionario`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `avaliacao_fisica`
--

INSERT INTO `avaliacao_fisica` (`id_avaliacao`, `data_e_hora`, `preco`, `id_aluno`, `id_funcionario`) VALUES
(1, '2020-10-31 20:20:00', 'R$30,00', 1, 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `funcionario`
--

CREATE TABLE IF NOT EXISTS `funcionario` (
  `id_funcionario` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) NOT NULL,
  `login` varchar(20) NOT NULL,
  `senha` varchar(20) NOT NULL,
  `cpf` varchar(15) NOT NULL,
  `rg` varchar(13) NOT NULL,
  `email` varchar(50) NOT NULL,
  `telefone` varchar(15) NOT NULL,
  `funcao` varchar(100) NOT NULL,
  `salario` varchar(10) NOT NULL,
  `horario_de_trabalho` varchar(15) NOT NULL,
  PRIMARY KEY (`id_funcionario`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `funcionario`
--

INSERT INTO `funcionario` (`id_funcionario`, `nome`, `login`, `senha`, `cpf`, `rg`, `email`, `telefone`, `funcao`, `salario`, `horario_de_trabalho`) VALUES
(1, 'Zé', 'Zezao', 'ZaoZé', '122.332.244-09', '23.568.123-00', 'zezao@hotmail.com', '(41)99881-0992', 'Zelador', 'R$500,00', '06:00 á 00:00');

-- --------------------------------------------------------

--
-- Estrutura da tabela `plano`
--

CREATE TABLE IF NOT EXISTS `plano` (
  `id_plano` int(11) NOT NULL AUTO_INCREMENT,
  `tipo_de_plano` varchar(10) NOT NULL,
  `valor` varchar(20) NOT NULL,
  `forma_de_pagamento` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `inicio_plano` date NOT NULL,
  `vencimento` date NOT NULL,
  `id_treinamento` int(11) NOT NULL,
  PRIMARY KEY (`id_plano`),
  KEY `id_aluno` (`id_treinamento`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `plano`
--

INSERT INTO `plano` (`id_plano`, `tipo_de_plano`, `valor`, `forma_de_pagamento`, `inicio_plano`, `vencimento`, `id_treinamento`) VALUES
(1, 'anual', '55 reais ao mês', 'dinheiro', '2020-08-21', '2021-08-24', 1),
(3, 'semestral', '65 ao mes', 'cartao de ', '2020-11-23', '2021-05-23', 1),
(6, 'trimestral', 'R$ 75,00', 'dinheiro', '2020-10-26', '2021-10-26', 1),
(8, 'mensal', 'R$ 100,00', 'cartao de credito', '2020-11-20', '2021-11-20', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `treinamento`
--

CREATE TABLE IF NOT EXISTS `treinamento` (
  `id_treinamento` int(11) NOT NULL AUTO_INCREMENT,
  `modalidade` varchar(20) NOT NULL,
  `especificacao` varchar(100) NOT NULL,
  `observacoes` tinytext,
  PRIMARY KEY (`id_treinamento`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `treinamento`
--

INSERT INTO `treinamento` (`id_treinamento`, `modalidade`, `especificacao`, `observacoes`) VALUES
(1, 'musculação', 'busca hipertrofia muscular', NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `treino_aluno`
--

CREATE TABLE IF NOT EXISTS `treino_aluno` (
  `id_treino` int(11) NOT NULL AUTO_INCREMENT,
  `tipo_de_treino` varchar(30) NOT NULL,
  `id_aluno` int(11) NOT NULL,
  `id_funcionario` int(11) NOT NULL,
  `treino` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id_treino`),
  KEY `id_aluno` (`id_aluno`,`id_funcionario`),
  KEY `id_funcionario` (`id_funcionario`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `treino_aluno`
--

INSERT INTO `treino_aluno` (`id_treino`, `tipo_de_treino`, `id_aluno`, `id_funcionario`, `treino`) VALUES
(1, 'hipertrofia 3x por semana', 1, 1, 'A - Peito e ombro\r\nSupino reto - 3X10\r\nSupino inclinado - 3X10\r\nCrucifixo - 4X12\r\nElevação Lateral - 4X12 Dropset\r\nElevação Frontal - 3X15 \r\nDesenvolvimento Arnold - 4X15 Supersérie\r\n\r\nB - Costas e bíceps\r\nBarra fixa - até falha 3x\r\nRemada alta - 3X12\r\nRemada curvada - 4X15\r\nRosca Scott - 3X12\r\nRosca Direta - 3X10\r\n\r\nC- Pernas e tríceps\r\nAgachamento - 4X12\r\nLegpress - 4X15\r\nExtensora - 4X12\r\nFrancês - 3X10\r\nPulley barra reta - 4X12\r\nTríceps corda - 3X10');

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `avaliacao_fisica`
--
ALTER TABLE `avaliacao_fisica`
  ADD CONSTRAINT `avaliacao_fisica_ibfk_1` FOREIGN KEY (`id_aluno`) REFERENCES `aluno` (`id_aluno`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `avaliacao_fisica_ibfk_2` FOREIGN KEY (`id_funcionario`) REFERENCES `funcionario` (`id_funcionario`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Limitadores para a tabela `plano`
--
ALTER TABLE `plano`
  ADD CONSTRAINT `plano_ibfk_2` FOREIGN KEY (`id_treinamento`) REFERENCES `treinamento` (`id_treinamento`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Limitadores para a tabela `treino_aluno`
--
ALTER TABLE `treino_aluno`
  ADD CONSTRAINT `treino_aluno_ibfk_1` FOREIGN KEY (`id_aluno`) REFERENCES `aluno` (`id_aluno`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `treino_aluno_ibfk_2` FOREIGN KEY (`id_funcionario`) REFERENCES `funcionario` (`id_funcionario`) ON DELETE RESTRICT ON UPDATE RESTRICT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Academia focada em Musculação, Aeróbicos e Artes Marciais.">
    <meta name="keywords" content="Academia, Zumba, Muay-Thay, Musculação, Pilates, ">
    <meta name="robots" content="index, follow">
    <meta name="author" content="Natan Cancian">
	<title>Academia Vidativa</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
</head>

<?php

//Sessão
session_start();
if(!empty($_SESSION['id_usuario'])){
	$teste = "teste se não está vazio <br>";
	echo $teste;
}

if(!isset($_SESSION['id_usuario'])){
	$teste = "teste se não existe";
	echo $teste;
}

var_dump($_SESSION);
/*$id = $_SESSION['id_user'];
$ids = $_SESSION['id_usuario'];
$idn = $_SESSION['nivel_usuario'];
$idl = $_SESSION['logado'];*/

//Conexão com banco e com um js
require_once 'php/db_connect.php';
require_once 'php/mensagem.php';

//Manipulação para cada tipo de plano
/*
	if(isset($_POST['btn-mensal'])){		
		$sql = "SELECT * FROM aluno WHERE id_aluno = '$id'";
		$resultado = mysqli_query($connect, $sql);
		$linha = mysqli_num_rows($resultado);
			if($linha == 1){
				$_SESSION['valido'] = true;
				 while($dados = mysqli_fetch_array($resultado)){                
                    if(!(empty($dados))){                        
                        foreach($dados as $dado){
                            echo $dado;
                        }
                    }
				$_SESSION['compra'] = $dados;
			}
				if(isset($_SESSION['compra'])){
					$sql = "SELECT * FROM plano WHERE tipo_de_plano = 'mensal'";
					$resultado = mysqli_query($connect, $sql);
					$row = mysqli_num_rows($resultado);
		  
		  				if($row > 0){//$sql = "SELECT nome FROM aluno WHERE id_aluno = '$id'";$resultado = //mysqli_query($connect,$sql);$row = mysqli_num_rows($resultado);

					  	  if($row == 1){		  	
							while($dados_compra = mysqli_fetch_array($resultado)){ 
								$_SESSION['compra-plano'] = true; 
									if(!(empty($dados_compra))){    
			                    		 $_SESSION['inf_compra'] = $dados_compra;
						 						//echo "<script>alert('Informações coletadas!');</script>";
								}							  
							}
						}
				$_SESSION['mensagem'] = "Plano selecionado! Prosseguindo para o carrinho de compras";
					header('Location: php/cdc/carrinho.php');	      
      }
	}
  }
}
*/
?>
<body>
	<header class="cabecalho">
		<h1 class="logo">
			<a title="Academia Vidativa">Academia Vidativa</a>							
			<a href="php/cdc/carrinho.php" id="link-carrinho"><img src="https://img.icons8.com/wired/60/000000/shopping-cart.png" id="carrinho"/></a>
			<img src="https://img.icons8.com/wired/60/000000/bottle-of-water.png" id="garrafa" />
			<img src="https://img.icons8.com/wired/64/000000/dumbbell.png" id="anilha" />
		</h1>
	</header>
	<nav class="menu">
		<ul>
			<li> <a href="tela_principal.php"> Home </a> </li>
			<li> <a href="planos.php"> Planos </a> </li>
			<li> <a href="servicos.html"> Serviços </a> </li>
			<li> <a href="treinamentos.php"> Treinos </a> </li>
			<li> <a href="cadastros.php">Cadastros</a></li>
			<li> <a href="tela_login.php"> Login </a> </li>

		<div class="social-icons">
			<a href="#"> <img src="https://img.icons8.com/cute-clipart/20/000000/facebook.png"/> </a>
			<a href="#"> <img src="https://img.icons8.com/cute-clipart/20/000000/instagram-new.png"/> </a>
			<a href="#"> <img src="https://img.icons8.com/cute-clipart/20/000000/twitter.png"/></a>
		</div>
		</ul>
	</nav>

<main class="servicos">
	<form action="<?php echo $_SERVER['PHP_SELF'];?>" method="POST">
	<article class="servico">
		<button name="btn-mensal"><img src="imagens/plano-mensal.jpg" alt="Plano Mensal"></button>
			<div class="plano">
				<a>Plano Mensal</a>
				<h4> 100,00 R$ ao mês</h4>
				<p> Parcelado no cartão, não aceitamos cheque</p>
			</div>
	</article>	
	<article class="servico">
		<button name="btn-trimestral"><img src="imagens/plano-trimestral.jpg" alt="Plano Trimestral"></button>
			<div class="plano">
				<a>Plano Trimestral</a>
				<h4> 70,00 R$ ao mês</h4>
				<p> Parcelado no cartão, não aceitamos cheque</p>
			</div>
	</article>	
	<article class="servico">
		<button name="btn-semestral"><img src="imagens/plano-semestral.jpg" alt="Plano Semestral"></button>
			<div class="plano">
				<a>Plano Semestral</a>
				<h4> 60,00 R$ ao mês</h4>
				<p> Parcelado no cartão, não aceitamos cheque</p>
			</div>
	</article>
	<article class="servico">
		<button name="btn-anual"><img src="imagens/plano-anual.jpg" alt="Plano Anual"></button>
			<div class="plano">
				<a>Plano Anual</a>
				<h4> 50,00 R$ ao mês</h4>
				<p> Parcelado no cartão, não aceitamos cheque</p>
			</div>
	</article>
	</form>
</main>
	<footer class="rodape">
		<p> &copy; Academia Vidativa - Todos os direitos reservados </p>
	</footer>
</body>
</html>
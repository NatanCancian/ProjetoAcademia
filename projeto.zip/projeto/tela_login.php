<?php
//Sessão 
session_start();

// Conexão
require_once 'php/db_connect.php';

// Mensagem 
require_once 'php/mensagem.php';

// Botão enviar
if(isset($_POST['btn-entrar'])){
    $erros = array();
    $login = mysqli_escape_string($connect, $_POST['login']);
    $senha = mysqli_escape_string($connect, $_POST['senha']);

    if(!(empty($login) or empty($senha))){
        $sql = "SELECT login FROM aluno WHERE login = '$login'";
        $resultado = mysqli_query($connect, $sql);
        $row = mysqli_num_rows($resultado);

        if($row > 0){
            $sql = "SELECT * FROM aluno WHERE login = '$login' AND senha = '$senha'";
            $resultado = mysqli_query($connect, $sql);
            $row = mysqli_num_rows($resultado);

            if($row == 1){
                while($dados = mysqli_fetch_array($resultado)){                
                $_SESSION['logado'] = true; 
                //mysqli_close($connect);
                    if(!(empty($dados))){                        
                        foreach($dados as $dado){
                            echo $dado;
                        }
                    }
             $_SESSION['id_usuario'] = $dados['id_aluno'];
             $_SESSION['nivel_usuario'] = $dados['nvl_usuario'];
                header('Location: tela_principal.php'); 
               }
            } else{
        $erros[] = "<script>alert('Usuário e senha não conferem');</script>";    
    }
        }else{
            $erros[] = "<script>alert('Usuário inexistente');</script>";
        }
    
    }else{
         $erros[] = "<script>alert('O campo login/senha precisa ser preenchido');</script>";
            }
            //error_log();
        } 
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <title>Tela de Login</title>
    <link rel="stylesheet" href="css/estilo.css">
    <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300&display=swap" rel="stylesheet">    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link rel="icon" href="imagens/dumbbell.jpg">
    <style type="text/css">
        #volta{
            position: absolute;
            background-attachment: fixed;
            font: 1.5em sans-serif;
        }
        .botao{
            width: 100%;
            border: none;
            outline: none;    
            height: 40px;
            background: #cecece;
            color: #fff;
            font-size: 18px;
            border-radius: 20px;
            margin-bottom: 20px;
        }
        .botao:hover{
            cursor: pointer;
            background: #ffc107;
            color: #000;
        }
        li{
            font-size: 2.5em;
            color:black;
        }
    </style>
</head>
<body>
    <?php
        if(!empty($erros)){
            foreach ($erros as $erro) {
                echo $erro;
            }
        }
    ?>
    <div class="caixa_login">
    <img src="imagens/icone.png" id="avatar">
        <a href="javascript: history.go(-1)" id="volta">&larr;</a>    
        <h1>Entre aqui</h1>
        <form action="<?php echo $_SERVER['PHP_SELF'];?>" method="POST">
            <p class="titulo">Nome de Usuário</p>
            <input type="text" name="login" placeholder="Coloque o nome de Usuário">
            <p class="titulo">Senha</p>
            <input type="password" name="senha" placeholder="Coloque sua senha">
            <button type="submit" class="botao" name="btn-entrar">Entrar</button>
            <!--<a href="nova-senha.php">Esqueceu sua senha?</a><br> PARA FUTURO(usar o PHPMAILER)-->
            <a href="novo-usuario.php">Não tem uma conta?</a>
        </form>    
    </div>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>

      <script type="text/javascript">
        M.AutoInit();
      </script>      
</body>
</html>

	<footer class="rodape">
		<p> &copy; Academia Vidativa - Todos os direitos reservados </p>
	</footer>
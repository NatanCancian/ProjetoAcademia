<?php
// Sessão
// session_start();

// Conexão com banco
require_once 'php/db_connect.php';
require_once 'php/mensagem.php';

// Clear
function clear($input){
    global $connect;
    //sql
    $var = mysqli_escape_string($connect,$input);
    //xss
    $var = htmlspecialchars($var);
    return $var;
}

if(isset($_POST['btn-entrar'])){
    $nome = clear($_POST['nome']);
    $data = clear($_POST['data']);
    $email = clear($_POST['email']);
    $login = clear($_POST['login']);
    $senha = clear($_POST['senha']);
    $cpf = clear($_POST['cpf']);
    $rg = clear($_POST['rg']);
    $telefone = clear($_POST['telefone']);

    if(!(empty($nome) or empty($data) or empty($email) or empty($login) or empty($senha) or empty($cpf) or empty($rg) or empty($telefone))){
            $sql = " INSERT INTO aluno (nome,data_de_nasc,login,senha,telefone,cpf,rg,email) VALUES ('$nome','$data','$login','$senha','$telefone','$cpf','$rg','$email')";
            if(mysqli_query($connect,$sql)){
                $_SESSION['mensagem'] = "Cadastrado com sucesso!";
                header('Location: tela_login.php');
            } else{
                $_SESSION['mensagem'] = "Erro ao cadastrar";
                header('Location: novo-usuario.php');
            }
    }


}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <title>Novo Usuário</title>
    <link rel="stylesheet" type="text/css" href="css/estilo.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <style type="text/css">

        @charset"UTF-8";

#volta{
    position: absolute;
    top: 115px;
    float: left;
}

h1#title{
    font-family: 'Rubik' sans-serif;
    font-size:1.9em;
    outline: none;
    border: none;
    padding: none;
}

.caixa_login{
    width: 32%;
    height: 877px;
    background-color: black;
    /*background-attachment: scroll;*/
    color: white;
    top: 50%;
    left: 50%;
    position: absolute;
    transform:translate(-50%,-50%);
    box-sizing: border-box;
    padding: 70px 30px;
    border-radius: 20px;
}

.caixa_login input[type="text"], input[type="password"], input[type="email"], input[type="date"]{
    border: none; 
    border-bottom: 1px solid #fff;
    background: transparent;
    outline: none;
    height: 30px;
    color: #fff;
    font-size: 16px;
}

p.titulo{
    margin-top: 5px;
}


    </style>
</head>
<body>
   	<div class="caixa_login">        
        <a href="javascript: history.go(-1)" id="volta">&larr;</a> 
        <h1 id="title">Crie sua conta aqui</h1>   
        <form action="<?php echo $_SERVER['PHP_SELF']?>" method="POST">
                <p class="titulo">Nome Completo</p>
                    <input type="text" name="nome" placeholder="Digite seu nome completo" required>
                <p class="titulo">Data de Nascimento</p>
                    <input type="date" name="data" placeholder="Digite sua Data de Nascimento" required>
                <p class="titulo">Email</p>
                    <input type="email" name="email" placeholder="Digite seu email" required>
                <p class="titulo">Login</p>
                    <input type="text" name="login" placeholder="Digite um nome para a sua conta" required>
                <p class="titulo">Senha</p>
                    <input type="password" name="senha" max="15" placeholder="Digite uma senha de até 15 caracteres" required>
                <p class="titulo">CPF</p>            
                    <input type="text" name="cpf" placeholder="Digite seu CPF" required>
                <p class="titulo">RG</p>
                    <input type="text" name="rg" placeholder="Digite seu RG" required>
                <p class="titulo">Telefone</p>
                    <input type="tel" name="telefone" placeholder="Digite seu telefone ou celular" required>
                <input type="submit" name="btn-entrar" value="Enviar">
            </form>   
    </div>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
      <script type="text/javascript">
        M.AutoInit();
      </script>      
</body>
</html>
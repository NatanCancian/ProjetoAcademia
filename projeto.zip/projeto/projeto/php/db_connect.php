<?php
//variaveis que vão fazer armazenar informações sobre a conexão

$servername = "localhost:3308";
$username = "root";
$password = "";
$db_name = "academia";

$connect = mysqli_connect($servername, $username, $password, $db_name);

if(mysqli_connect_error()){
	echo "Falha na Conexão : " . mysqli_connect_error();
}
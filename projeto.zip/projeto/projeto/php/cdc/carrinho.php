<?php
session_start();
//Header
require_once 'includes/header.php';
?>

<div class="row">
	<div class="col s12 m6 push-m3">
		<h3 class="light">Carrinho</h3>
		<table class="striped">
			<thead>
				<tr>
					<th>Número da matrícula:</th>
					<th>Nome do aluno:</th>
					<th>Plano Escolhido:</th>
					<th>Valor:</th>	
					<th>Forma de Pagamento:</th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td>-</td>
					<td>-</td>
					<td>-</td>
					<td>-</td>
					<td>-</td>
				</tr>				
			</tbody>
			<tfoot>
				
			</tfoot>
		</table>
		<br/>
		<button class="btn" name="btn-finalizar">Finalizar Compra</button>
	    <a href="javascript: history.go(-1)" class="btn light red">Cancelar</a>          
	</div>
</div>

<?php
//Footer
require_once 'includes/footer.php';
?>
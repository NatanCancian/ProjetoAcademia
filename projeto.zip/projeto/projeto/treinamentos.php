<?php

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Academia focada em Musculação, Aeróbicos e Artes Marciais.">
    <meta name="keywords" content="Academia, Zumba, Muay-Thay, Musculação, Pilates, Avaliação-Física">
    <meta name="robots" content="index, follow">
    <meta name="author" content="Natan Cancian">
	<title>Academia Vidativa</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro&display=swap" rel="stylesheet">
</head>
<body>
	<header class="cabecalho">
		<h1 class="logo">
			<a title="Academia Vidativa">Academia Vidativa</a>				
			<a href="php/cdc/carrinho.php" id="link-carrinho"><img src="https://img.icons8.com/wired/60/000000/shopping-cart.png" id="carrinho"/></a>
			<img src="https://img.icons8.com/wired/60/000000/bottle-of-water.png" id="garrafa"/>
			<img src="https://img.icons8.com/wired/64/000000/dumbbell.png" id="anilha"/>
		</h1>
	</header>
	<nav class="menu">
		<ul>
			<li> <a href="tela_principal.php"> Home </a> </li>
			<li> <a href="planos.php"> Planos </a> </li>
			<li> <a href="servicos.php"> Serviços </a> </li>
			<li> <a href="treinamentos.php"> Treinos </a> </li>
			<li> <a href="cadastros.php">Cadastros</a></li>
			<li> <a href="tela_login.php"> Login </a> </li>

		<div class="social-icons">
			<a href="#"> <img src="https://img.icons8.com/cute-clipart/20/000000/facebook.png"/> </a>
			<a href="#"> <img src="https://img.icons8.com/cute-clipart/20/000000/instagram-new.png"/> </a>
			<a href="#"> <img src="https://img.icons8.com/cute-clipart/20/000000/twitter.png"/></a>
		</div>
		</ul>
	</nav>
		<?php

		?>
	<!-- Retirar o comentário somente após implementar o formulário para criação de treino<footer class="rodape">
		<p> &copy; Academia Vidativa - Todos os direitos reservados </p>
	</footer>-->
</body>
</html>
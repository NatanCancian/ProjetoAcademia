<?php
// Sessão
//session_start();
if(isset($_SESSION['mensagem'])){ ?>
	
<script type="text/javascript">
	//Mensagem de Cadastro
	window.onload = function(){		
		alert('<?php echo $_SESSION['mensagem'];?>');
	 	M.toast({html: '<?php echo $_SESSION['mensagem'];?>' });
	}
</script>
<?php
} 
session_unset();
?>
<?php
// Sessão
session_start();

// Conexão
require_once 'php/db_connect.php';

// Verificação
	if(!isset($_SESSION['logado'])){
		header('Location: tela_login.php');
	}

// Captura e uso deDados(id e nivel do usuario) 
// Validação dos níveis de usuário

$id = $_SESSION['id_usuario'];
$nvl_user = $_SESSION['nivel_usuario'];
$sql = "SELECT * FROM aluno WHERE id_aluno = '$id' AND nvl_usuario = '$nvl_user'";
$resultado = mysqli_query($connect, $sql);
$dados = mysqli_fetch_array($resultado);
$_SESSION['id_user'] = $id;
var_dump($_SESSION);
//var_dump($GLOBALS);
//mysqli_close($connect);

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Academia focada em Musculação, Aeróbicos e Artes Marciais.">
    <meta name="keywords" content="Academia, Zumba, Muay-Thay, Musculação, Pilates ">
    <meta name="robots" content="index, follow">
    <meta name="author" content="Natan Cancian">
	<title>Academia Vidativa</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro&display=swap" rel="stylesheet">
	<link rel="icon" href="imagens/letreiro.jpg">
</head>
<body>
	<header class="cabecalho">
		<h1 class="logo">
			<a title="Academia Vidativa">Academia Vidativa</a>
			<h1 id="nome-usuario"> Seja Bem Vindo <?php echo $dados['nome'] . " :)";?></h1>			
			<a href="php/cdc/carrinho.php" id="link-carrinho"><img src="https://img.icons8.com/wired/60/000000/shopping-cart.png" id="carrinho"/></a>
			<img src="https://img.icons8.com/wired/60/000000/bottle-of-water.png" id="garrafa"/>
			<img src="https://img.icons8.com/wired/60/000000/dumbbell.png" id="anilha"/>
		</h1>
	</header>
	<nav class="menu">
		<ul>
			<li> <a href="tela_principal.php"> Home </a> </li>
			<li> <a href="planos.php"> Planos </a> </li>
			<li> <a href="servicos.html"> Serviços </a> </li>
			<li> <a href="treinamentos.php"> Treinos </a> </li>
			<li> <a href="cadastros.php">Cadastros</a></li>
			<li> <a href="tela_login.php"> Login </a> </li>

		<div class="social-icons">
			<a href="#"> <img src="https://img.icons8.com/cute-clipart/20/000000/facebook.png"/> </a>
			<a href="#"> <img src="https://img.icons8.com/cute-clipart/20/000000/instagram-new.png"/> </a>
			<a href="#"> <img src="https://img.icons8.com/cute-clipart/20/000000/twitter.png"/></a>
		</div>
		</ul>
	</nav>
	<main class="principal"> 
		<article class="sobre">
			<h2> Sobre nós</h2>
				<img src="imagens/fundo1.jpg" alt="Academia Vidativa">
				<p>O Lorem Ipsum é um texto modelo da indústria tipográfica e de impressão. O Lorem Ipsum tem vindo a ser o texto padrão usado por estas indústrias desde o ano de 1500, quando uma misturou os caracteres de um texto para criar um espécime de livro. Este texto não só sobreviveu 5 séculos, mas também o salto para a tipografia electrónica, mantendo-se essencialmente inalterada. Foi popularizada nos anos 60 com a disponibilização das folhas de Letraset, que continham passagens com Lorem Ipsum, e mais recentemente com os programas de publicação como o Aldus PageMaker que incluem versões do Lorem Ipsum.</p><br><br>

				<p>É um facto estabelecido de que um leitor é distraído pelo conteúdo legível de uma página quando analisa a sua mancha gráfica. Logo, o uso de Lorem Ipsum leva a uma distribuição mais ou menos normal de letras, ao contrário do uso de "Conteúdo aqui, conteúdo aqui", tornando-o texto legível. Muitas ferramentas de publicação electrónica e editores de páginas web usam actualmente o Lorem Ipsum como o modelo de texto usado por omissão, e uma pesquisa por "lorem ipsum" irá encontrar muitos websites ainda na sua infância. Várias versões têm evoluído ao longo dos anos, por vezes por acidente, por vezes propositadamente (como no caso do humor).</p> 
		</article>
		<a href="php/logout.php" id="saida">Sair</a>
		<aside class="onde-estamos"> 
			<h2>Onde estamos</h2>
			<p> Av. Brasil, 9399 - Bairro Coqueiral, Cascavel - PR</p>
			<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d904.3390541565311!2d-53.48910020376978!3d-24.953992325646595!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94f3d6b28e04b6bb%3A0x51f8cb5a6a39bf32!2sVIDATIVA%20ACADEMIA!5e0!3m2!1spt-BR!2sbr!4v1586143552941!5m2!1spt-BR!2sbr"></iframe>
			<h2>Contatos</h2>
			<ul>
				<li> <img src="https://img.icons8.com/cute-clipart/20/000000/phone.png"/> (45) 0023-2323</li>
				<li> <img src="https://img.icons8.com/cute-clipart/20/000000/cell-phone.png"/> (45) 93456-9874</li>
				<li> <img src="https://img.icons8.com/bubbles/20/000000/gmail.png"/> academiavidativa@gmail.com</li>
			</ul>
		</aside>
	</main>
	<section class="newsletter">
		<h3> Newsletter</h3>
		<p> Receba nossas promoções por email </p>
		<form action="news.php" method="post">
			<input type="text" name="nomeUs" placeholder="Seu nome">
			<input type="email" name="mailUs" placeholder="Seu email">
			<button name="env-email">Cadastrar</button>
		</form>
	</section>
	<footer class="rodape">
		<p> &copy; Academia Vidativa - Todos os direitos reservados </p>
	</footer>
</body>
</html>
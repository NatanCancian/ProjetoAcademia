CREATE DATABASE  IF NOT EXISTS `academia` /*!40100 DEFAULT CHARACTER SET utf8 */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `academia`;
-- MySQL dump 10.13  Distrib 8.0.18, for Win64 (x86_64)
--
-- Host: localhost    Database: academia
-- ------------------------------------------------------
-- Server version	8.0.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `aluno`
--

DROP TABLE IF EXISTS `aluno`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aluno` (
  `id_aluno` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) NOT NULL,
  `data_de_nasc` date NOT NULL,
  `nvl_acesso` int(1) NOT NULL DEFAULT '1',
  `login` varchar(15) NOT NULL,
  `senha` varchar(15) NOT NULL,
  `telefone` varchar(255) NOT NULL,
  `cpf` varchar(15) NOT NULL,
  `rg` varchar(15) NOT NULL,
  `email` varchar(200) NOT NULL,
  `id_plano` int(11) NOT NULL,
  `id_treinamento` int(11) NOT NULL,
  PRIMARY KEY (`id_aluno`),
  KEY `id_plano` (`id_plano`),
  KEY `id_treinamento` (`id_treinamento`),
  CONSTRAINT `aluno_ibfk_1` FOREIGN KEY (`id_plano`) REFERENCES `plano` (`id_plano`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `aluno_ibfk_2` FOREIGN KEY (`id_treinamento`) REFERENCES `treinamento` (`id_treinamento`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aluno`
--

LOCK TABLES `aluno` WRITE;
/*!40000 ALTER TABLE `aluno` DISABLE KEYS */;
INSERT INTO `aluno` (`id_aluno`, `nome`, `data_de_nasc`, `nvl_acesso`, `login`, `senha`, `telefone`, `cpf`, `rg`, `email`, `id_plano`, `id_treinamento`) VALUES (1,'Natan Cancian','2002-09-22',1,'natan_cancian','natan01','(45)-998225362','111.222.343-01','22.567.980-9','natanzaleski@gmail.com',1,1),(2,'admin','2020-01-01',1,'admin','admin','(45)99822-5362','222.444.221-00','33.221.345-0','admin@gmail.com',2,1);
/*!40000 ALTER TABLE `aluno` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `avaliacao_fisica`
--

DROP TABLE IF EXISTS `avaliacao_fisica`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `avaliacao_fisica` (
  `id_avaliacao` int(11) NOT NULL AUTO_INCREMENT,
  `data_e_hora` datetime NOT NULL,
  `preco` varchar(10) NOT NULL,
  `id_aluno` int(11) NOT NULL,
  `id_funcionario` int(11) NOT NULL,
  PRIMARY KEY (`id_avaliacao`),
  KEY `id_aluno` (`id_aluno`),
  KEY `id_funcionario` (`id_funcionario`),
  CONSTRAINT `avaliacao_fisica_ibfk_1` FOREIGN KEY (`id_aluno`) REFERENCES `aluno` (`id_aluno`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `avaliacao_fisica_ibfk_2` FOREIGN KEY (`id_funcionario`) REFERENCES `funcionario` (`id_funcionario`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `avaliacao_fisica`
--

LOCK TABLES `avaliacao_fisica` WRITE;
/*!40000 ALTER TABLE `avaliacao_fisica` DISABLE KEYS */;
INSERT INTO `avaliacao_fisica` (`id_avaliacao`, `data_e_hora`, `preco`, `id_aluno`, `id_funcionario`) VALUES (1,'2020-10-31 20:20:00','R$30,00',1,1);
/*!40000 ALTER TABLE `avaliacao_fisica` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `funcionario`
--

DROP TABLE IF EXISTS `funcionario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `funcionario` (
  `id_funcionario` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) NOT NULL,
  `nvl_acesso` int(1) DEFAULT '2',
  `login` varchar(20) NOT NULL,
  `senha` varchar(20) NOT NULL,
  `cpf` varchar(15) NOT NULL,
  `rg` varchar(13) NOT NULL,
  `email` varchar(50) NOT NULL,
  `telefone` varchar(15) NOT NULL,
  `funcao` varchar(100) NOT NULL,
  `salario` varchar(10) NOT NULL,
  `horario_de_trabalho` varchar(15) NOT NULL,
  PRIMARY KEY (`id_funcionario`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `funcionario`
--

LOCK TABLES `funcionario` WRITE;
/*!40000 ALTER TABLE `funcionario` DISABLE KEYS */;
INSERT INTO `funcionario` (`id_funcionario`, `nome`, `nvl_acesso`, `login`, `senha`, `cpf`, `rg`, `email`, `telefone`, `funcao`, `salario`, `horario_de_trabalho`) VALUES (1,'Zé',2,'Zezao','ZaoZé','122.332.244-09','23.568.123-00','zezao@hotmail.com','(41)99881-0992','Zelador','R$500,00','06:00 á 00:00');
/*!40000 ALTER TABLE `funcionario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plano`
--

DROP TABLE IF EXISTS `plano`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plano` (
  `id_plano` int(11) NOT NULL AUTO_INCREMENT,
  `tipo_de_plano` varchar(10) NOT NULL,
  `valor` varchar(20) NOT NULL,
  `forma_de_pagamento` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `inicio_plano` date NOT NULL,
  `vencimento` date NOT NULL,
  `id_treinamento` int(11) NOT NULL,
  PRIMARY KEY (`id_plano`),
  KEY `plano_ibfk_1` (`id_treinamento`),
  CONSTRAINT `plano_ibfk_1` FOREIGN KEY (`id_treinamento`) REFERENCES `treinamento` (`id_treinamento`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plano`
--

LOCK TABLES `plano` WRITE;
/*!40000 ALTER TABLE `plano` DISABLE KEYS */;
INSERT INTO `plano` (`id_plano`, `tipo_de_plano`, `valor`, `forma_de_pagamento`, `inicio_plano`, `vencimento`, `id_treinamento`) VALUES (1,'anual','R$ 55,00','dinheiro','2020-08-21','2021-08-24',1),(2,'semestral','R$ 65,00','dinheiro','2020-11-23','2021-05-23',1),(3,'trimestral','R$ 75,00','dinheiro','2020-10-26','2021-10-26',1),(4,'mensal','R$ 100,00','dinheiro','2020-11-20','2021-11-20',1);
/*!40000 ALTER TABLE `plano` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `treinamento`
--

DROP TABLE IF EXISTS `treinamento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `treinamento` (
  `id_treinamento` int(11) NOT NULL AUTO_INCREMENT,
  `modalidade` varchar(20) NOT NULL,
  `especificacao` varchar(100) NOT NULL,
  `observacoes` tinytext,
  PRIMARY KEY (`id_treinamento`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `treinamento`
--

LOCK TABLES `treinamento` WRITE;
/*!40000 ALTER TABLE `treinamento` DISABLE KEYS */;
INSERT INTO `treinamento` (`id_treinamento`, `modalidade`, `especificacao`, `observacoes`) VALUES (1,'musculação','busca hipertrofia muscular',NULL);
/*!40000 ALTER TABLE `treinamento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `treino_aluno`
--

DROP TABLE IF EXISTS `treino_aluno`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `treino_aluno` (
  `id_treino` int(11) NOT NULL AUTO_INCREMENT,
  `tipo_de_treino` varchar(30) NOT NULL,
  `id_aluno` int(11) NOT NULL,
  `id_funcionario` int(11) NOT NULL,
  `id_treinamento` int(11) NOT NULL,
  `treino` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id_treino`),
  KEY `id_aluno` (`id_aluno`),
  KEY `id_funcionario` (`id_funcionario`),
  KEY `id_treinamento` (`id_treinamento`),
  CONSTRAINT `treino_aluno_ibfk_1` FOREIGN KEY (`id_aluno`) REFERENCES `aluno` (`id_aluno`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `treino_aluno_ibfk_2` FOREIGN KEY (`id_funcionario`) REFERENCES `funcionario` (`id_funcionario`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `treino_aluno_ibfk_3` FOREIGN KEY (`id_treinamento`) REFERENCES `treinamento` (`id_treinamento`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `treino_aluno`
--

LOCK TABLES `treino_aluno` WRITE;
/*!40000 ALTER TABLE `treino_aluno` DISABLE KEYS */;
INSERT INTO `treino_aluno` (`id_treino`, `tipo_de_treino`, `id_aluno`, `id_funcionario`, `id_treinamento`, `treino`) VALUES (1,'hipertrofia 3x por semana',1,1,1,'A - Peito e ombro\r\nSupino reto - 3X10\r\nSupino inclinado - 3X10\r\nCrucifixo - 4X12\r\nElevação Lateral - 4X12 Dropset\r\nElevação Frontal - 3X15 \r\nDesenvolvimento Arnold - 4X15 Supersérie\r\n\r\nB - Costas e bíceps\r\nBarra fixa - até falha 3x\r\nRemada alta - 3X12\r\nRemada curvada - 4X15\r\nRosca Scott - 3X12\r\nRosca Direta - 3X10\r\n\r\nC- Pernas e tríceps\r\nAgachamento - 4X12\r\nLegpress - 4X15\r\nExtensora - 4X12\r\nFrancês - 3X10\r\nPulley barra reta - 4X12\r\nTríceps corda - 3X10');
/*!40000 ALTER TABLE `treino_aluno` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-11-10 21:42:04

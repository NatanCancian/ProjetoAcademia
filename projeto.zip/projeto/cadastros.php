<?php
// Aqui vai ser a index para o crud de funcionários
// e para criação de treinos.

echo "Olá";

?>


<?php
// Implementar com o PHPMAILER dps(baixar no github e configurar a biblioteca).

//Arquivo que altera a senha do usuário

//Conexão com banco
require_once 'php/db_connect.php';

if(isset($_POST['rec-senha'])){

    $mailS = mysqli_escape_string($connect, $_POST['mailSenha']);

    if(!(filter_var($mailS, FILTER_VALIDATE_EMAIL))){
    	$erro[] = "<script>alert('Email Inválido!');</script>";
    }

      $sql = " SELECT email FROM aluno WHERE email = '$mailS'";
       $resultado = mysqli_query($connect,$sql);
		//$ar = mysqli_fetch_assoc($resultado);
        $row = mysqli_num_rows($resultado);

        if($row == 0){
        	$erro[] = "<script>alert('O email informado não existe no banco de dados!');</script>";
        }

    	if(empty($erro) and $row > 0){

	 	   $novaSenha = substr(md5(time()), 0, 8);
    		$nscpt = md5(md5($novaSenha));    

   				if(mail($mailS, "Sua nova senha", "Sua nova senha é: " . $novaSenha)){
   					$sql = "UPDATE aluno SET senha = '$nscpt' WHERE email = '$mailS'";
    				$resultado = mysqli_query($connect,$sql) or die(mysqli_error());

    				if(mysqli_query()){
    					$erro[] = "<script>alert('Senha alterada com sucesso!');</script>";
    				}
    	} 
 	  }
 	}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="utf-8">
	<title>Nova senha</title>
    <link rel="stylesheet" href="css/estilo.css">
    <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300&display=swap" rel="stylesheet">    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
     <style type="text/css">

        @charset"UTF-8";

#volta{
    position: absolute;
    top: 115px;
    float: left;
}

h1{
	color: white;
    font-family: 'Rubik' sans-serif;
    font-size:3em;
    outline: none;
    border: none;
    padding: none;
}

.caixa_senha{
    width: 32%;
    height: 600px;
    background-color: black;
    background-attachment: scroll;
    color: white;
    top: 50%;
    left: 50%;
    position: absolute;
    transform:translate(-50%,-50%);
    box-sizing: border-box;
    padding: 70px 30px;
    border-radius: 20px;
}

.caixa_login input[type="email"]{
    border: none; 
    border-bottom: 1px solid #fff;
    background: transparent;
    outline: none;
    height: 30px;
    color: #fff;
    font-size: 16px;
}

p.titulo{
    margin-top: 5px;
}

#rec{
	font-size: 3.5em;
	color: yellow;
}

.caixa_login button[type="submit"]{
	width: 100%;
	margin-top: 5px;
    border: none;
    outline: none;    
    height: 40px;
    background: #cecece;
    color: #fff;
    font-size: 18px;
    border-radius: 12px;
}

.caixa_login button[type="submit"]:hover{
    cursor: pointer;
    background: #ffc107;
    color: #000;
}
    </style>
</head>
<body>
	<?php
		if(!empty($erro)){
            foreach ($erro as $erros) {
                echo $erros;
            }
        }
	?>
	<h1 id="rec">Recuperação de Senha</h1>
	<div class="caixa_login">        
        <a href="javascript: history.go(-1)" id="volta">&larr;</a> 
        <h1 id="title">Recupere sua senha aqui</h1>   
        <form action="<?php echo $_SERVER['PHP_SELF']?>" method="POST">
          			<p class="titulo">Coloque seu melhor email</p>
                    <input type="email" name="mailSenha" placeholder="Digite o email cadastrado em seu perfil" required>
                <button type="submit" name="rec-senha" value="Enviar">Enviar</button>
            </form>   
    	</div>
	</form>
</body>
</html>